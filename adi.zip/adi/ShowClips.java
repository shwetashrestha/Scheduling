/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adi;

/**
 *
 * @author nepho
 */
class ShowClips {
    private int id;
   private String shows;
   private String clip;
   private int duration;
    private String day;
    private String starttime;
    
    
    public ShowClips(int id,String shows,String clip,int duration,String day,String starttime){
    this.id=id;
    this.shows=shows;
    this.clip=clip;
    this.duration=duration;
    this.day=day;
    this.starttime=starttime;
    
    }
    public int getid(){
    return id;
    }
      public String getshows(){
    return shows;
    }
     public String getclip(){
    return clip;
    }
        public int getduration(){
    return duration;
    }
       public String getday(){
    return day;
    }
    
      public String getstarttime(){
    return starttime;
    }
    
   
   
}
