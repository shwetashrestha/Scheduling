/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adi;

/**
 *
 * @author nepho
 */
public class ComboBoxItem {
    private int Id;
    private String Name;
    
    public ComboBoxItem(int catId, String catName){
        this.Id = catId;
        this.Name = catName;
    }
    
    public int getId(){
        return Id;
    }
    
    public void setId(int id){
        this.Id = id;
    }
    
    public String getName(){
        return Name;
    }
    
    public void setName(String catName){
        this.Name = catName;
    }
}

