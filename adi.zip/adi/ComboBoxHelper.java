/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adi;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;


/**
 *
 * @author nepho
 */
public class ComboBoxHelper{
    public HashMap<String, Integer> map;
    public ComboBoxHelper(String sql){
      
      Connection conn = DBConnection.ConnectDB();
      
       try {
 conn.createStatement();
 PreparedStatement pst=(PreparedStatement) conn.prepareStatement(sql);
           ResultSet rs=(ResultSet) pst.executeQuery();
           ComboBoxItem cmi;
           map = new HashMap<String,Integer>();
           while(rs.next()){
               cmi = new ComboBoxItem(rs.getInt(1), rs.getString(2));
               map.put(cmi.getName(), cmi.getId());
           }
           
       } catch (SQLException sqle) {
            System.out.println(sqle);
        }    
       
   }
}
