/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adi;

/**
 *
 * @author Srijal
 */
public class Generaltime {
    public String starttime;
    public String endtime;
      public String getstarttime(){
    return starttime;
    }
    
     public String getendtime(){
    return endtime;
    }
    
}
