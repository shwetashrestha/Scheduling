/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adi;

/**
 *
 * @author nepho
 */
class Shows extends  GeneralClass {
     
   
      private int duration;
     private String pname;
    public Shows(int id,String name,int duration,String pname){
    this.id=id;
    this.name=name;
    this.duration=duration;
     this.pname=pname;
    }
   
     public int getduration(){
    return duration;
    }
       public String getpname(){
    return pname;
    }
}
