/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adi;

/**
 *
 * @author nepho
 */
class Schedules extends Generaltime {
    private int id;
    private String day;
      private String shows;
     
    
    
    public Schedules(int id,String day,String shows,String starttime,String endtime){
    this.id=id;
    this.day=day;
    this.shows=shows;
    this.starttime=starttime;
    this.endtime=endtime;
    }
    public int getid(){
    return id;
    }
     public String getday(){
    return day;
    }
     public String getshows(){
    return shows;
    }
     
    
}
