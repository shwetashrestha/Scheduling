/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adi;

/**
 *
 * @author nepho
 */
class License extends Generaltime {
    private int id;
    private String clip;
    private int times;
   
    
    public License(int id,String clip,String starttime,String endtime,int times){
    this.id=id;
    this.clip=clip;
    this.starttime=starttime;
    this.endtime=endtime;
    this.times=times;
    
    
    }
    public int getid(){
    return id;
    }
    
     public String getclip(){
    return clip;
    }
    
      public int gettimes(){
    return times;
    }
    
}
