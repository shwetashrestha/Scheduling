/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adi;

/**
 *
 * @author nepho
 */
class Clip extends GeneralClass{
   
      private int duration;
        private String type;
      private String advertise;
     private String genre;
    
    public Clip(int id,String name,int duration,String type,String advertise,String genre){
    this.id=id;
    this.name=name;
    this.duration=duration;
     this.type=type;
    this.advertise=advertise;
    this.genre=genre;
    }
  
     public int getduration(){
    return duration;
    }
      public String gettype(){
    return type;
    }
     public String getadvertise(){
    return advertise;
    }
       public String getgenre(){
    return genre;
    }
}
