/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adi;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author Srijal
 */
public class DBConnection {
Connection conn=null;
	
	
	public static Connection ConnectDB()
	{
		try
		{
			//driver class
                    Class.forName("com.mysql.jdbc.Driver");
			//connection object
                        Connection conn=  DriverManager.getConnection("jdbc:mysql://localhost/cliporganiser","root","");
		//JOptionPane.showMessageDialog(null,"Connected to Database");
                       
                        return conn;
	

		}
		catch(Exception e){ 
                JOptionPane.showMessageDialog(null,e);
                return null;
                }
	}

    


}

    